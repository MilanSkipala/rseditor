#!/bin/sh
export LD_LIBRARY_PATH=`pwd`/libs
./RailSlotEditor
